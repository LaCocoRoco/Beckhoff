package de.beckhoff.jni;

public class AdsConstants {
   public static final int ADSTRANS_NOTRANS = 0;
   public static final int ADSTRANS_CLIENTCYCLE = 1;
   public static final int ADSTRANS_CLIENT1REQ = 2;
   public static final int ADSTRANS_SERVERCYCLE = 3;
   public static final int ADSTRANS_SERVERONCHA = 4;

   private AdsConstants() {
   }
}
