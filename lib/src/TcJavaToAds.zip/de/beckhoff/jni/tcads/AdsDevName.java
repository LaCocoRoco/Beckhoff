package de.beckhoff.jni.tcads;

public class AdsDevName {
   private String mDevName;

   public AdsDevName() {
      this.mDevName = "";
   }

   public AdsDevName(String lDevName) {
      this.mDevName = lDevName;
   }

   public void setDevName(String lDevName) {
      this.mDevName = lDevName;
   }

   public String getDevName() {
      return this.mDevName;
   }
}
