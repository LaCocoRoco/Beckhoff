package de.beckhoff.jni.tcads;

public class AmsNetId {
   private char[] mB;

   public AmsNetId() {
      this.mB = new char[6];
   }

   public AmsNetId(char[] bytes) {
      if (bytes.length == 6) {
         this.mB = bytes;
      }

   }

   public char[] getCharArr() {
      return this.mB;
   }

   public void setCharArr(char[] bytes) {
      if (bytes.length == 6) {
         this.mB = bytes;
      } else {
         throw new IllegalArgumentException("Setting the AmsNetId failed.");
      }
   }
}
