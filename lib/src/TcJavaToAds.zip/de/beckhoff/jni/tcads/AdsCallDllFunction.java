package de.beckhoff.jni.tcads;

import de.beckhoff.jni.JNIBool;
import de.beckhoff.jni.JNIByteBuffer;
import de.beckhoff.jni.JNILong;
import java.lang.reflect.Field;
import java.util.regex.Pattern;

public class AdsCallDllFunction {
   public static final short ADS_FIXEDNAMESIZE = 16;
   public static final short AMSPORT_LOGGER = 100;
   public static final short AMSPORT_EVENTLOG = 110;
   public static final short AMSPORT_R0_RTIME = 200;
   public static final short AMSPORT_R0_TRACE = 290;
   public static final short AMSPORT_R0_IO = 300;
   public static final short AMSPORT_R0_SPS = 400;
   public static final short AMSPORT_R0_NC = 500;
   public static final short AMSPORT_R0_NCSAF = 501;
   public static final short AMSPORT_R0_NCSVB = 511;
   public static final short AMSPORT_R0_CNC = 600;
   public static final short AMSPORT_R0_PLC = 801;
   public static final short AMSPORT_R0_PLC_RTS1 = 801;
   public static final short AMSPORT_R0_PLC_RTS2 = 811;
   public static final short AMSPORT_R0_PLC_RTS3 = 821;
   public static final short AMSPORT_R0_PLC_RTS4 = 831;
   public static final long AMSPORT_R0_CAM = 900L;
   public static final long AMSPORT_R0_CAMTOOL = 950L;
   public static final long AMSPORT_R3_SYSSERV = 10000L;
   public static final int ADSIGRP_SYMTAB = 61440;
   public static final int ADSIGRP_SYMNAME = 61441;
   public static final int ADSIGRP_SYMVAL = 61442;
   public static final int ADSIGRP_SYM_HNDBYNAME = 61443;
   public static final int ADSIGRP_SYM_VALBYNAME = 61444;
   public static final int ADSIGRP_SYM_VALBYHND = 61445;
   public static final int ADSIGRP_SYM_RELEASEHND = 61446;
   public static final int ADSIGRP_SYM_INFOBYNAME = 61447;
   public static final int ADSIGRP_SYM_VERSION = 61448;
   public static final int ADSIGRP_SYM_INFOBYNAMEEX = 61449;
   public static final int ADSIGRP_SYM_DOWNLOAD = 61450;
   public static final int ADSIGRP_SYM_UPLOAD = 61451;
   public static final int ADSIGRP_SYM_UPLOADINFO = 61452;
   public static final int ADSIGRP_SYMNOTE = 61456;
   public static final int ADSIGRP_IOIMAGE_RWIB = 61472;
   public static final int ADSIGRP_IOIMAGE_RWIX = 61473;
   public static final int ADSIGRP_IOIMAGE_RWOB = 61488;
   public static final int ADSIGRP_IOIMAGE_RWOX = 61489;
   public static final int ADSIGRP_IOIMAGE_CLEARI = 61504;
   public static final int ADSIGRP_IOIMAGE_CLEARO = 61520;
   public static final int ADSIGRP_DEVICE_DATA = 61696;
   public static final int ADSIOFFS_DEVDATA_ADSSTATE = 0;
   public static final int ADSIOFFS_DEVDATA_DEVSTATE = 2;
   public static final short AMSEVENT_ROUTERSTOP = 0;
   public static final short AMSEVENT_ROUTERSTART = 1;
   public static final short AMSEVENT_ROUTERREMOVED = 2;
   public static final long ADSERR_NO_ERR = 0L;
   public static final long ADSERR_INTERNAL_ERR = 1L;
   public static final long ADSERR_NO_RUNTIME = 2L;
   public static final long ADSERR_MEM_ALLOC_LOCK_ERR = 3L;
   public static final long ADSERR_INSERT_MAILBOX_ERR = 4L;
   public static final long ADSERR_WRONG_HMSG = 5L;
   public static final long ADSERR_PORT_NOT_FOUND = 6L;
   public static final long ADSERR_MACHINE_NOT_FOUND = 7L;
   public static final long ADSERR_UNKN_CMD_ID = 8L;
   public static final long ADSERR_BAD_TASK_ID = 9L;
   public static final long ADSERR_NO_IO = 10L;
   public static final long ADSERR_UNKN_AMS_CMD = 11L;
   public static final long ADSERR_WIN32_ERR = 12L;
   public static final long ADSERR_PORT_NOT_CONN = 13L;
   public static final long ADSERR_INV_AMS_LEN = 14L;
   public static final long ADSERR_INV_AMS_NETID = 15L;
   public static final long ADSERR_LOW_INSTALL_LVL = 16L;
   public static final long ADSERR_NO_DEBUG = 17L;
   public static final long ADSERR_PORT_DISABLED = 18L;
   public static final long ADSERR_PORT_ALREADY_CONN = 19L;
   public static final long ADSERR_AMSSYNC_WIN32_ERR = 20L;
   public static final long ADSERR_AMSSYNC_TIMEOUT = 21L;
   public static final long ADSERR_AMSSYNC_AMS_ERR = 22L;
   public static final long ADSERR_AMSSYNC_NO_INDEX_MAP = 23L;
   public static final long ADSERR_INV_AMS_PORT = 24L;
   public static final long ADSERR_NO_MEM = 25L;
   public static final long ADSERR_TCP_SEND_ERR = 26L;
   public static final long ADSERR_HOST_UNREACHABLE = 27L;
   public static final long ROUTERERR_NOLOCKEDMEMORY = 1280L;
   public static final long ROUTERERR_RESIZEMEMORY = 1281L;
   public static final long ROUTERERR_MAILBOXFULL = 1282L;
   public static final long ROUTERERR_DEBUGBOXFULL = 1283L;
   public static final long ROUTERERR_UNKNOWNPORTTYPE = 1284L;
   public static final long ROUTERERR_NOTINITIALIZED = 1285L;
   public static final long ROUTERERR_PORTALREADYINUSE = 1286L;
   public static final long ROUTERERR_NOTREGISTERED = 1287L;
   public static final long ROUTERERR_NOMOREQUEUES = 1288L;
   public static final long ROUTERERR_INVALIDPORT = 1289L;
   public static final long ROUTERERR_NOTACTIVATED = 1290L;
   public static final long ADSERR_ERRCLASS_DEVICE_ERR = 1792L;
   public static final long ADSERR_SRVICE_NOT_SUPP = 1793L;
   public static final long ADSERR_INV_IGRP = 1794L;
   public static final long ADSERR_INV_IOFF = 1795L;
   public static final long ADSERR_READWRITE_NOT_PERMIT = 1796L;
   public static final long ADSERR_INV_PARAM_SIZE = 1797L;
   public static final long ADSERR_INV_PARAM_VALS = 1798L;
   public static final long ADSERR_DEV_NOT_RDY = 1799L;
   public static final long ADSERR_DEV_BUSY = 1800L;
   public static final long ADSERR_INV_CONTEXT = 1801L;
   public static final long ADSERR_OUTOF_MEM = 1802L;
   public static final long ADSERR_INV_PARAM_VALS2 = 1803L;
   public static final long ADSERR_REQ_ITEM_NOT_FOUND = 1804L;
   public static final long ADSERR_SYNTAX_ERROR = 1805L;
   public static final long ADSERR_OBJ_MISMATCH = 1806L;
   public static final long ADSERR_OBJ_ALRDY_EXISTS = 1807L;
   public static final long ADSERR_SYMB_NOT_FOUND = 1808L;
   public static final long ADSERR_INV_SYMB = 1809L;
   public static final long ADSERR_INV_SERVER_STATE = 1810L;
   public static final long ADSERR_ADSTRANSMODE_NOT_SUPP = 1811L;
   public static final long ADSERR_INV_NOT_HDL = 1812L;
   public static final long ADSERR_NOTCLIENT_NOT_REG = 1813L;
   public static final long ADSERR_NOMORE_NOT_HDL = 1814L;
   public static final long ADSERR_SIZE_TOOBIG_FOR_WATCH = 1815L;
   public static final long ADSERR_DEV_NOT_INIT = 1816L;
   public static final long ADSERR_DEVICE_TIMEOUT = 1817L;
   public static final long ADSERR_QUERYINTERFACE_FAILED = 1818L;
   public static final long ADSERR_WRONG_INTERFACE_REQ = 1819L;
   public static final long ADSERR_INV_CLASS_ID = 1820L;
   public static final long ADSERR_INV_OBJ_ID = 1821L;
   public static final long ADSERR_REQ_PENDING = 1822L;
   public static final long ADSERR_REQ_ABORTED = 1823L;
   public static final long ADSERR_SIGNAL_WARN = 1824L;
   public static final long ADSERR_INV_ARR_INDEX = 1825L;
   public static final long ADSERR_SYMB_NOT_ACTIVE = 1826L;
   public static final long ADSERR_ACCESS_DENIED = 1827L;
   public static final long ADSERR_ERRCLASS_CLIENT_ERR = 1856L;
   public static final long ADSERR_INV_PARAM_AT_SERVICE = 1857L;
   public static final long ADSERR_EMPTY_POLL_LIST = 1858L;
   public static final long ADSERR_VAR_CONN_IN_USE = 1859L;
   public static final long ADSERR_INVOKE_ID_IN_USE = 1860L;
   public static final long ADSERR_TIMEOUT_ELAPSED = 1861L;
   public static final long ADSERR_WIN32_SUBSYSTEM_ERR = 1862L;
   public static final long ADSERR_INV_CLIENT_TIMEOUT = 1863L;
   public static final long ADSERR_ADSPORT_CLOSED = 1864L;
   public static final long ADSERR_ERRCLASS_INTERNAL_ERR = 1872L;
   public static final long ADSERR_HASHTBL_OVERFLOW = 1873L;
   public static final long ADSERR_HASHTBL_KEY_NOT_FOUND = 1874L;
   public static final long ADSERR_NOMORE_SYMB_IN_CACHE = 1875L;
   public static final long ADSERR_INV_RESP_RECEIVED = 1876L;
   public static final long ADSERR_SYNC_PORT_LOCKED = 1877L;
   public static final long RTERR_INTERNAL = 4096L;
   public static final long RTERR_BADTIMERPERIODS = 4097L;
   public static final long RTERR_INVALIDTASKPTR = 4098L;
   public static final long RTERR_INVALIDSTACKPTR = 4099L;
   public static final long RTERR_PRIOEXISTS = 4100L;
   public static final long RTERR_NOMORETCB = 4101L;
   public static final long RTERR_NOMORESEMAS = 4102L;
   public static final long RTERR_NOMOREQUEUES = 4103L;
   public static final long RTERR_EXTIRQALREADYDEF = 4109L;
   public static final long RTERR_EXTIRQNOTDEF = 4110L;
   public static final long RTERR_EXTIRQINSTALLFAILED = 4111L;
   public static final long RTERR_IRQLNOTLESSOREQUAL = 4112L;
   public static final long WINSKERR_ATT_OPER_UNREACHHOST = 10060L;
   public static final long WINSKERR_CONN_TIMEOUT = 10061L;
   public static final long WINSKERR_CONN_REFUSED = 10065L;
   private static AdsCallbackObject adsCallbackObject = null;
   public static long jniWrapperDllVersion = 0L;
   private static final String SYSTEM_LIBPATHS = "sys_paths";
   private static final String JVM_BITNESS_PROPNAME = "sun.arch.data.model";
   private static final String JAVA_LIBPATH_PROPNAME = "java.library.path";

   private AdsCallDllFunction() {
   }

   private static void ForceReloadLibraryPath() {
      try {
         Field fieldSysPath = ClassLoader.class.getDeclaredField("sys_paths");
         fieldSysPath.setAccessible(true);
         fieldSysPath.set((Object)null, (Object)null);
      } catch (NoSuchFieldException var1) {
         System.out.println("Failed to adapt the java library path!");
      } catch (IllegalAccessException var2) {
         System.out.println("Failed to adapt the java library path!");
      }

   }

   protected void finalize() {
      callDllDoWhenUnloadDll();
   }

   private static native long callDllDoInitDll();

   private static native long callDllDoWhenUnloadDll();

   private static native long callDllDoInitCallbacks(Object var0);

   private static void doInitCallbacks() {
      if (adsCallbackObject == null) {
         adsCallbackObject = new AdsCallbackObject();
         callDllDoInitCallbacks(adsCallbackObject);
      }

   }

   public static AdsCallbackObject getAdsCallbackObject() {
      doInitCallbacks();
      return adsCallbackObject;
   }

   private static native long callDllAdsGetDllVersion(AdsVersion var0);

   private static native long callDllAdsPortOpen();

   private static native long callDllAdsPortClose();

   private static native long callDllAdsGetLocalAddress(AmsAddr var0);

   private static native long callDllAdsGetLocalAddressn(AmsAddr var0);

   private static native long callDllAdsSyncReadReq(Object var0, long var1, long var3, long var5, Object var7);

   private static native long callDllAdsSyncWriteReqArray(Object var0, long var1, long var3, long var5, byte[] var7);

   private static native long callDllAdsSyncReadWriteReq(Object var0, long var1, long var3, long var5, Object var7, long var8, Object var10);

   private static native long callDllAdsSyncReadStateReq(Object var0, Object var1, Object var2);

   private static native long callDllAdsSyncReadDeviceInfoReq(Object var0, Object var1, Object var2);

   private static native long callDllAdsSyncWriteControlReq(Object var0, int var1, int var2, long var3, Object var5);

   private static native long callDllAdsSyncGetTimeout(Object var0);

   private static native long callDllAdsSyncSetTimeout(long var0);

   private static native long callDllAdsSyncAddDeviceNotificationReq(Object var0, long var1, long var3, Object var5, long var6, Object var8);

   private static native long callDllAdsSyncDelDeviceNotificationReq(Object var0, Object var1);

   private static native long callDllAdsAmsRegisterRouterNotification();

   private static native long callDllAdsAmsUnRegisterRouterNotification();

   private static native long callDllAdsAmsPortEnabled(Object var0);

   private static native long callDllAdsPortOpenEx();

   private static native long callDllAdsPortCloseEx(long var0);

   private static native long callDllAdsGetLocalAddressEx(long var0, AmsAddr var2);

   private static native long callDllAdsSyncReadReqEx(Object var0, long var1, long var3, long var5, Object var7, Object var8);

   private static native long callDllAdsSyncReadReqEx2(long var0, Object var2, long var3, long var5, long var7, Object var9, Object var10);

   private static native long callDllAdsSyncWriteReqExArray(long var0, Object var2, long var3, long var5, long var7, byte[] var9);

   private static native long callDllAdsSyncReadWriteReqEx(Object var0, long var1, long var3, long var5, Object var7, long var8, Object var10, Object var11);

   private static native long callDllAdsSyncReadWriteReqEx2(long var0, Object var2, long var3, long var5, long var7, Object var9, long var10, Object var12, Object var13);

   private static native long callDllAdsSyncReadStateReqEx(long var0, Object var2, Object var3, Object var4);

   private static native long callDllAdsSyncReadDeviceInfoReqEx(long var0, Object var2, Object var3, Object var4);

   private static native long callDllAdsSyncWriteControlReqEx(long var0, Object var2, int var3, int var4, long var5, Object var7);

   private static native long callDllAdsSyncGetTimeoutEx(long var0, Object var2);

   private static native long callDllAdsSyncSetTimeoutEx(long var0, long var2);

   private static native long callDllAdsSyncAddDeviceNotificationReqEx(long var0, Object var2, long var3, long var5, Object var7, long var8, Object var10);

   private static native long callDllAdsSyncDelDeviceNotificationReqEx(long var0, Object var2, Object var3);

   private static native long callDllAdsAmsPortEnabledEx(long var0, Object var2);

   public static AdsVersion adsGetDllVersion() {
      AdsVersion lAdsVersion = new AdsVersion();
      callDllAdsGetDllVersion(lAdsVersion);
      return lAdsVersion;
   }

   public static long adsPortOpen() {
      return callDllAdsPortOpen();
   }

   public static long adsPortClose() {
      return callDllAdsPortClose();
   }

   public static long getLocalAddress(AmsAddr lj_AmsAddr) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsGetLocalAddress(lj_AmsAddr) : callDllAdsGetLocalAddressn(lj_AmsAddr);
      }
   }

   public static long adsSyncReadReq(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return lj_pData == null ? 1803L : callDllAdsSyncReadReq(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData);
      }
   }

   public static long adsSyncWriteReqArray(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, byte[] lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return lj_pData == null ? 1803L : callDllAdsSyncWriteReqArray(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData);
      }
   }

   public static long adsSyncWriteReq(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return lj_pData == null ? 1803L : adsSyncWriteReqArray(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData.getByteArray());
      }
   }

   public static long adsSyncReadWriteReq(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_lengthRead, JNIByteBuffer lj_pDataRead, long lj_lengthWrite, JNIByteBuffer lj_pDataWrite) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDataRead == null) {
         return 1803L;
      } else {
         return lj_pDataWrite == null ? 1803L : callDllAdsSyncReadWriteReq(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_lengthRead, lj_pDataRead, lj_lengthWrite, lj_pDataWrite);
      }
   }

   public static long adsSyncReadStateReq(AmsAddr lj_AmsAddr, AdsState lj_nAdsState, AdsState lj_nDeviceState) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_nAdsState == null) {
         return 1803L;
      } else {
         return lj_nDeviceState == null ? 1803L : callDllAdsSyncReadStateReq(lj_AmsAddr, lj_nAdsState, lj_nDeviceState);
      }
   }

   public static long adsSyncReadDeviceInfoReq(AmsAddr lj_AmsAddr, AdsDevName lj_pDevName, AdsVersion lj_pVersion) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDevName == null) {
         return 1803L;
      } else {
         return lj_pVersion == null ? 1803L : callDllAdsSyncReadDeviceInfoReq(lj_AmsAddr, lj_pDevName, lj_pVersion);
      }
   }

   public static long adsSyncWriteControlReq(AmsAddr lj_AmsAddr, int lj_adsState, int lj_deviceState, long lj_length, JNIByteBuffer lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return lj_pData == null ? 1803L : callDllAdsSyncWriteControlReq(lj_AmsAddr, lj_adsState, lj_deviceState, lj_length, lj_pData);
      }
   }

   public static long adsSyncSetTimeout(long lj_nMs) {
      return callDllAdsSyncSetTimeout(lj_nMs);
   }

   public static long adsSyncGetTimeout(JNILong lj_pMs) {
      if (lj_pMs == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncGetTimeout(lj_pMs) : 1793L;
      }
   }

   public static long adsSyncAddDeviceNotificationReq(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, AdsNotificationAttrib lj_pNoteAttrib, long lj_hUser, JNILong lj_pNotification) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pNoteAttrib == null) {
         return 1803L;
      } else if (lj_pNotification == null) {
         return 1803L;
      } else {
         doInitCallbacks();
         return callDllAdsSyncAddDeviceNotificationReq(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_pNoteAttrib, lj_hUser, lj_pNotification);
      }
   }

   public static long adsSyncDelDeviceNotificationReq(AmsAddr lj_AmsAddr, JNILong lj_hNotification) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return lj_hNotification == null ? 1803L : callDllAdsSyncDelDeviceNotificationReq(lj_AmsAddr, lj_hNotification);
      }
   }

   public static long adsAmsRegisterRouterNotification() {
      doInitCallbacks();
      return callDllAdsAmsRegisterRouterNotification();
   }

   public static long adsAmsUnRegisterRouterNotification() {
      return callDllAdsAmsUnRegisterRouterNotification();
   }

   public static long adsAmsPortEnabled(JNIBool lj_pEnabled) {
      if (lj_pEnabled == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsAmsPortEnabled(lj_pEnabled) : 1793L;
      }
   }

   public static long adsPortOpenEx() {
      return jniWrapperDllVersion != 1L ? callDllAdsPortOpenEx() : 1793L;
   }

   public static long adsPortCloseEx(long lj_port) {
      return jniWrapperDllVersion != 1L ? callDllAdsPortCloseEx(lj_port) : 1793L;
   }

   public static long getLocalAddressEx(long lj_port, AmsAddr lj_AmsAddr) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsGetLocalAddressEx(lj_port, lj_AmsAddr) : 1793L;
      }
   }

   /** @deprecated */
   @Deprecated
   public static long adsSyncReadReqEx(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData, long lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else if (jniWrapperDllVersion != 1L) {
         JNILong pBytesRead = new JNILong();
         return callDllAdsSyncReadReqEx(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData, pBytesRead);
      } else {
         return 1793L;
      }
   }

   public static long adsSyncReadReqEx(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData, JNILong lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadReqEx(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData, lj_pBytesRead) : 1793L;
      }
   }

   /** @deprecated */
   @Deprecated
   public static long adsSyncReadReqEx2(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData, long lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else if (jniWrapperDllVersion != 1L) {
         JNILong pBytesRead = new JNILong();
         return callDllAdsSyncReadReqEx2(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData, pBytesRead);
      } else {
         return 1793L;
      }
   }

   public static long adsSyncReadReqEx2(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData, JNILong lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadReqEx2(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData, lj_pBytesRead) : 1793L;
      }
   }

   public static long adsSyncWriteReqExArray(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, byte[] lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncWriteReqExArray(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData) : 1793L;
      }
   }

   public static long adsSyncWriteReqEx(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_length, JNIByteBuffer lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? adsSyncWriteReqExArray(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_length, lj_pData.getByteArray()) : 1793L;
      }
   }

   /** @deprecated */
   @Deprecated
   public static long adsSyncReadWriteReqEx(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_lengthRead, JNIByteBuffer lj_pDataRead, long lj_lengthWrite, JNIByteBuffer lj_pDataWrite, long lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDataRead == null) {
         return 1803L;
      } else if (lj_pDataWrite == null) {
         return 1803L;
      } else if (jniWrapperDllVersion != 1L) {
         JNILong pBytesRead = new JNILong();
         return callDllAdsSyncReadWriteReqEx(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_lengthRead, lj_pDataRead, lj_lengthWrite, lj_pDataWrite, pBytesRead);
      } else {
         return 1793L;
      }
   }

   public static long adsSyncReadWriteReqEx(AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_lengthRead, JNIByteBuffer lj_pDataRead, long lj_lengthWrite, JNIByteBuffer lj_pDataWrite, JNILong lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDataRead == null) {
         return 1803L;
      } else if (lj_pDataWrite == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadWriteReqEx(lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_lengthRead, lj_pDataRead, lj_lengthWrite, lj_pDataWrite, lj_pBytesRead) : 1793L;
      }
   }

   /** @deprecated */
   @Deprecated
   public static long adsSyncReadWriteReqEx2(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_lengthRead, JNIByteBuffer lj_pDataRead, long lj_lengthWrite, JNIByteBuffer lj_pDataWrite, long lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDataRead == null) {
         return 1803L;
      } else if (lj_pDataWrite == null) {
         return 1803L;
      } else if (jniWrapperDllVersion != 1L) {
         JNILong pBytesRead = new JNILong();
         return callDllAdsSyncReadWriteReqEx2(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_lengthRead, lj_pDataRead, lj_lengthWrite, lj_pDataWrite, pBytesRead);
      } else {
         return 1793L;
      }
   }

   public static long adsSyncReadWriteReqEx2(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, long lj_lengthRead, JNIByteBuffer lj_pDataRead, long lj_lengthWrite, JNIByteBuffer lj_pDataWrite, JNILong lj_pBytesRead) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDataRead == null) {
         return 1803L;
      } else if (lj_pDataWrite == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadWriteReqEx2(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_lengthRead, lj_pDataRead, lj_lengthWrite, lj_pDataWrite, lj_pBytesRead) : 1793L;
      }
   }

   public static long adsSyncReadStateReqEx(long lj_port, AmsAddr lj_AmsAddr, AdsState lj_nAdsState, AdsState lj_nDeviceState) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_nAdsState == null) {
         return 1803L;
      } else if (lj_nDeviceState == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadStateReqEx(lj_port, lj_AmsAddr, lj_nAdsState, lj_nDeviceState) : 1793L;
      }
   }

   public static long adsSyncReadDeviceInfoReqEx(long lj_port, AmsAddr lj_AmsAddr, AdsDevName lj_pDevName, AdsVersion lj_pVersion) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pDevName == null) {
         return 1803L;
      } else if (lj_pVersion == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncReadDeviceInfoReqEx(lj_port, lj_AmsAddr, lj_pDevName, lj_pVersion) : 1793L;
      }
   }

   public static long adsSyncWriteControlReqEx(long lj_port, AmsAddr lj_AmsAddr, int lj_adsState, int lj_deviceState, long lj_length, JNIByteBuffer lj_pData) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pData == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncWriteControlReqEx(lj_port, lj_AmsAddr, lj_adsState, lj_deviceState, lj_length, lj_pData) : 1793L;
      }
   }

   public static long adsSyncGetTimeoutEx(long lj_port, JNILong lj_pMs) {
      if (lj_pMs == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncGetTimeoutEx(lj_port, lj_pMs) : 1793L;
      }
   }

   public static long adsSyncSetTimeoutEx(long lj_port, long lj_nMs) {
      return jniWrapperDllVersion != 1L ? callDllAdsSyncSetTimeoutEx(lj_port, lj_nMs) : 1793L;
   }

   public static long adsSyncAddDeviceNotificationReqEx(long lj_port, AmsAddr lj_AmsAddr, long lj_indexGroup, long lj_indexOffset, AdsNotificationAttrib lj_pNoteAttrib, long lj_hUser, JNILong lj_pNotification) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_pNoteAttrib == null) {
         return 1803L;
      } else if (lj_pNotification == null) {
         return 1803L;
      } else if (jniWrapperDllVersion != 1L) {
         doInitCallbacks();
         return callDllAdsSyncAddDeviceNotificationReqEx(lj_port, lj_AmsAddr, lj_indexGroup, lj_indexOffset, lj_pNoteAttrib, lj_hUser, lj_pNotification);
      } else {
         return 1793L;
      }
   }

   public static long adsSyncDelDeviceNotificationReqEx(long lj_port, AmsAddr lj_AmsAddr, JNILong lj_hNotification) {
      if (lj_AmsAddr == null) {
         return 15L;
      } else if (lj_hNotification == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsSyncDelDeviceNotificationReqEx(lj_port, lj_AmsAddr, lj_hNotification) : 1793L;
      }
   }

   public static long adsAmsPortEnabledEx(long lj_port, JNIBool lj_pEnabled) {
      if (lj_pEnabled == null) {
         return 1803L;
      } else {
         return jniWrapperDllVersion != 1L ? callDllAdsAmsPortEnabledEx(lj_port, lj_pEnabled) : 1793L;
      }
   }

   static {
      String bitness = System.getProperty("sun.arch.data.model");
      String libpath = System.getProperty("java.library.path");
      boolean retry = false;

      do {
         retry = false;

         try {
            System.setProperty("java.library.path", libpath);
            ForceReloadLibraryPath();
            System.loadLibrary("AdsToJava");
         } catch (UnsatisfiedLinkError var6) {
            if (var6.getMessage().equals("no AdsToJava in java.library.path")) {
               System.out.println("AdsToJava.dll not found. Check your PATH environment variable!");
            } else if (!var6.getMessage().endsWith("Can't load IA 32-bit .dll on a AMD 64-bit platform") && !var6.getMessage().endsWith("Can't load AMD 64-bit .dll on a IA 32-bit platform")) {
               System.out.println(var6.getMessage());
            } else {
               String exmsg = var6.getMessage();
               String invalpath = exmsg.substring(0, exmsg.indexOf("adstojava.dll") - 1);
               libpath = libpath.replaceAll("(?i)" + Pattern.quote(invalpath) + "(;)?", "");
               retry = true;
            }
         } catch (SecurityException var7) {
            System.out.println("The current thread cannot load the library AdsToJava.dll!");
         }
      } while(retry);

      jniWrapperDllVersion = callDllDoInitDll();
   }
}
