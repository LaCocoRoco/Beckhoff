package de.beckhoff.jni.tcads;

public class AdsState {
   public static final short ADSSTATE_INVALID = 0;
   public static final short ADSSTATE_IDLE = 1;
   public static final short ADSSTATE_RESET = 2;
   public static final short ADSSTATE_INIT = 3;
   public static final short ADSSTATE_START = 4;
   public static final short ADSSTATE_RUN = 5;
   public static final short ADSSTATE_STOP = 6;
   public static final short ADSSTATE_SAVECFG = 7;
   public static final short ADSSTATE_LOADCFG = 8;
   public static final short ADSSTATE_POWERFAILURE = 9;
   public static final short ADSSTATE_POWERGOOD = 10;
   public static final short ADSSTATE_ERROR = 11;
   public static final short ADSSTATE_SHUTDOWN = 12;
   public static final short ADSSTATE_SUSPEND = 13;
   public static final short ADSSTATE_RESUME = 14;
   private short mState = 0;

   public void setState(short lState) {
      this.mState = lState;
   }

   public short getState() {
      return this.mState;
   }
}
