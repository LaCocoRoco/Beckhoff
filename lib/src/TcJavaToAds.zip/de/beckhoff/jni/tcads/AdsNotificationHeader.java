package de.beckhoff.jni.tcads;

public class AdsNotificationHeader {
   private long mHNotification = 0L;
   private long mNTimeStamp = 0L;
   private byte[] data;

   public AdsNotificationHeader(int length) {
      this.data = new byte[length];
   }

   public long getHNotification() {
      return this.mHNotification;
   }

   public long getNTimeStamp() {
      return this.mNTimeStamp;
   }

   public byte[] getData() {
      return this.data;
   }
}
