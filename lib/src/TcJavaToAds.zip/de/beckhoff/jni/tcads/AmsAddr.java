package de.beckhoff.jni.tcads;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AmsAddr {
   private AmsNetId mNetId = new AmsNetId();
   public int mPort = 0;
   public char mNetIdPart0;
   public char mNetIdPart1;
   public char mNetIdPart2;
   public char mNetIdPart3;
   public char mNetIdPart4;
   public char mNetIdPart5;

   public void setPort(int lPort) {
      this.mPort = lPort;
   }

   public int getPort() {
      return this.mPort;
   }

   public void setNetId(AmsNetId netId) {
      this.mNetId = netId;
   }

   public AmsNetId getNetId() {
      return this.mNetId;
   }

   public void setNetIDPart(char netIdPart, int partIndex) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         if (partIndex >= 0 & partIndex < this.mNetId.getCharArr().length) {
            this.mNetId.getCharArr()[partIndex] = netIdPart;
         }
      } else {
         switch(partIndex) {
         case 0:
            this.mNetIdPart0 = netIdPart;
            break;
         case 1:
            this.mNetIdPart1 = netIdPart;
            break;
         case 2:
            this.mNetIdPart2 = netIdPart;
            break;
         case 3:
            this.mNetIdPart3 = netIdPart;
            break;
         case 4:
            this.mNetIdPart4 = netIdPart;
            break;
         case 5:
            this.mNetIdPart5 = netIdPart;
         }
      }

   }

   public char getNetIDPart(int partIndex) {
      char result = 0;
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         if (partIndex >= 0 & partIndex < this.mNetId.getCharArr().length) {
            result = this.mNetId.getCharArr()[partIndex];
         }
      } else {
         switch(partIndex) {
         case 0:
            result = this.mNetIdPart0;
            break;
         case 1:
            result = this.mNetIdPart1;
            break;
         case 2:
            result = this.mNetIdPart2;
            break;
         case 3:
            result = this.mNetIdPart3;
            break;
         case 4:
            result = this.mNetIdPart4;
            break;
         case 5:
            result = this.mNetIdPart5;
         }
      }

      return result;
   }

   public void setNetIdStringEx(String lNetId) throws IllegalArgumentException {
      String block = "(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
      Pattern pattern = Pattern.compile("^(?:" + block + "\\.){5}" + block + "$");
      Matcher matcher = pattern.matcher(lNetId);
      if (!matcher.matches()) {
         throw new IllegalArgumentException("String could not be matched.");
      } else {
         char i = 0;
         String[] var6 = lNetId.split("\\.");
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            String s = var6[var8];
            char part = (char)Short.parseShort(s);
            this.setNetIDPart(part, i);
            ++i;
         }

      }
   }

   public String getNetIdString() {
      StringBuilder ret = new StringBuilder();

      for(int i = 0; i >= 0 & i < 6; ++i) {
         ret.append((short)this.getNetIDPart(i));
         if (i != 5) {
            ret.append('.');
         }
      }

      return ret.toString();
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdString(String lNetId) {
      int i = 0;
      String[] var3 = lNetId.split("\\.");
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String s = var3[var5];
         char part = (char)Short.parseShort(s);
         this.setNetIDPart(part, i);
         ++i;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart0() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[0] : this.mNetIdPart0;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart0(char lNetIdPart0) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[0] = lNetIdPart0;
      } else {
         this.mNetIdPart0 = lNetIdPart0;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart1() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[1] : this.mNetIdPart1;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart1(char lNetIdPart1) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[1] = lNetIdPart1;
      } else {
         this.mNetIdPart1 = lNetIdPart1;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart2() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[2] : this.mNetIdPart2;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart2(char lNetIdPart2) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[2] = lNetIdPart2;
      } else {
         this.mNetIdPart2 = lNetIdPart2;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart3() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[3] : this.mNetIdPart3;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart3(char lNetIdPart3) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[3] = lNetIdPart3;
      } else {
         this.mNetIdPart3 = lNetIdPart3;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart4() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[4] : this.mNetIdPart4;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart4(char lNetIdPart4) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[4] = lNetIdPart4;
      } else {
         this.mNetIdPart4 = lNetIdPart4;
      }

   }

   /** @deprecated */
   @Deprecated
   public char getNetIdPart5() {
      return AdsCallDllFunction.jniWrapperDllVersion != 1L ? this.mNetId.getCharArr()[5] : this.mNetIdPart5;
   }

   /** @deprecated */
   @Deprecated
   public void setNetIdPart5(char lNetIdPart5) {
      if (AdsCallDllFunction.jniWrapperDllVersion != 1L) {
         this.mNetId.getCharArr()[5] = lNetIdPart5;
      } else {
         this.mNetIdPart5 = lNetIdPart5;
      }

   }
}
