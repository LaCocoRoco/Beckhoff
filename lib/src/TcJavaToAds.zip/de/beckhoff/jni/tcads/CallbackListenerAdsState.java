package de.beckhoff.jni.tcads;

public interface CallbackListenerAdsState {
   void onEvent(AmsAddr var1, AdsNotificationHeader var2, long var3);
}
