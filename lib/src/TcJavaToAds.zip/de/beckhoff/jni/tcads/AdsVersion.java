package de.beckhoff.jni.tcads;

public class AdsVersion {
   private char mVersion = 0;
   private char mRevision = 0;
   private short mBuild = 0;

   public char getVersion() {
      return this.mVersion;
   }

   public char getRevision() {
      return this.mRevision;
   }

   public short getBuild() {
      return this.mBuild;
   }
}
