package de.beckhoff.jni.tcads;

import de.beckhoff.jni.JNILong;
import java.util.Vector;

public class AdsCallbackObject {
   private static Vector<CallbackListenerAdsRouter> mCallbackListenersAdsRouter = new Vector();
   private static Vector<CallbackListenerAdsState> mCallbackListenersAdsState = new Vector();

   protected void doAdsRouterCallback(JNILong nReason) {
      this.processCallbackAdsRouter(nReason.getLong());
   }

   public void addListenerCallbackAdsRouter(CallbackListenerAdsRouter listener) {
      mCallbackListenersAdsRouter.addElement(listener);
   }

   public void removeListenerCallbackAdsRouter(CallbackListenerAdsRouter listener) {
      mCallbackListenersAdsRouter.removeElement(listener);
   }

   public void processCallbackAdsRouter(long nReason) {
      for(int i = 0; i < mCallbackListenersAdsRouter.size(); ++i) {
         ((CallbackListenerAdsRouter)mCallbackListenersAdsRouter.elementAt(i)).onEvent(nReason);
      }

   }

   protected void doAdsStateCallback(AmsAddr pAddr, AdsNotificationHeader pNotification, JNILong hUser) {
      this.processCallbackAdsState(pAddr, pNotification, hUser.getLong());
   }

   public void addListenerCallbackAdsState(CallbackListenerAdsState listener) {
      mCallbackListenersAdsState.addElement(listener);
   }

   public void removeListenerCallbackAdsState(CallbackListenerAdsState listener) {
      mCallbackListenersAdsState.removeElement(listener);
   }

   public void processCallbackAdsState(AmsAddr pAddr, AdsNotificationHeader pNotification, long hUser) {
      if (!mCallbackListenersAdsState.isEmpty()) {
         for(int i = 0; i < mCallbackListenersAdsState.size(); ++i) {
            ((CallbackListenerAdsState)mCallbackListenersAdsState.elementAt(i)).onEvent(pAddr, pNotification, hUser);
         }
      }

   }
}
