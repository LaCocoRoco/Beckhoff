package de.beckhoff.jni.tcads;

public interface CallbackListenerAdsRouter {
   void onEvent(long var1);
}
