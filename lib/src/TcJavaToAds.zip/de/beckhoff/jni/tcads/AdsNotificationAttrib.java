package de.beckhoff.jni.tcads;

public class AdsNotificationAttrib {
   private long mCbLength = 0L;
   private int mNTransMode = 0;
   private long mNMaxDelay = 0L;
   private long mNCycleTime = 0L;
   private long mDwChangeFilter = 0L;

   public void setCbLength(long lCbLength) {
      this.mCbLength = lCbLength;
   }

   public long getCbLength() {
      return this.mCbLength;
   }

   public void setNTransMode(int lNTransMode) {
      this.mNTransMode = lNTransMode;
   }

   public int getNTransMode() {
      return this.mNTransMode;
   }

   public void setNMaxDelay(long lNMaxDelay) {
      this.mNMaxDelay = lNMaxDelay;
   }

   public long getNMaxDelay() {
      return this.mNMaxDelay;
   }

   public void setNCycleTime(long lNCycleTime) {
      if (lNCycleTime != 0L) {
         this.mNCycleTime = lNCycleTime;
      } else {
         this.mNCycleTime = this.mDwChangeFilter;
      }

   }

   public long getNCycleTime() {
      return this.mNCycleTime;
   }

   public void setDwChangeFilter(long lDwChangeFilter) {
      this.mDwChangeFilter = lDwChangeFilter;
      this.mNCycleTime = this.mDwChangeFilter;
   }

   public long getDwChangeFilter() {
      return this.mDwChangeFilter;
   }
}
