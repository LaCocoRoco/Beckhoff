package de.beckhoff.jni.tcads;

import de.beckhoff.jni.Convert;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AdsSymbolEntry {
   private static final char MIN_BUFF_LEN = '\u001e';
   private int entryLength;
   private int iGroup;
   private int iOffs;
   private int size;
   private int dataType;
   private int flags;
   private short nameLength;
   private short typeLength;
   private short commentLength;
   private String name;
   private String type;
   private String comment;

   public AdsSymbolEntry(byte[] buff) throws IllegalArgumentException {
      try {
         this.retrieveInformationItems(buff);
      } catch (IllegalArgumentException var3) {
         throw var3;
      }
   }

   public void setSymbolEntryBuff(byte[] buff) {
      this.retrieveInformationItems(buff);
   }

   public int getEntryLen() {
      return this.entryLength;
   }

   public int getiGroup() {
      return this.iGroup;
   }

   public int getiOffs() {
      return this.iOffs;
   }

   public int getSize() {
      return this.size;
   }

   public int getDataType() {
      return this.dataType;
   }

   public int getFlags() {
      return this.flags;
   }

   public int getNameLength() {
      return this.nameLength;
   }

   public int getTypeLength() {
      return this.typeLength;
   }

   public int getCommentLength() {
      return this.commentLength;
   }

   public String getName() {
      return this.name;
   }

   public String getType() {
      return this.type;
   }

   public String getComment() {
      return this.comment;
   }

   private void retrieveInformationItems(byte[] buff) throws IllegalArgumentException {
      boolean isBufferValid = true;
      ByteBuffer bb = ByteBuffer.wrap(buff);
      bb.order(ByteOrder.LITTLE_ENDIAN);
      if (buff.length >= 30) {
         this.entryLength = bb.getInt();
         this.iGroup = bb.getInt();
         this.iOffs = bb.getInt();
         this.size = bb.getInt();
         this.dataType = bb.getInt();
         this.flags = bb.getInt();
         this.nameLength = bb.getShort();
         this.typeLength = bb.getShort();
         this.commentLength = bb.getShort();
      } else {
         isBufferValid = false;
      }

      short additionalLenght = (short)(this.nameLength + 1 + this.typeLength + 1 + this.commentLength + 1);
      if (isBufferValid & buff.length - 30 >= additionalLenght) {
         byte[] bt = new byte[this.nameLength + 1];
         bb.get(bt, 0, this.nameLength + 1);
         this.name = Convert.ByteArrToString(bt);
         bt = new byte[this.typeLength + 1];
         bb.get(bt, 0, this.typeLength + 1);
         this.type = Convert.ByteArrToString(bt);
         bt = new byte[this.commentLength + 1];
         bb.get(bt, 0, this.commentLength + 1);
         this.comment = Convert.ByteArrToString(bt);
      } else {
         isBufferValid = false;
      }

      if (!isBufferValid) {
         throw new IllegalArgumentException("The buffer did not have the correct format.");
      }
   }
}
