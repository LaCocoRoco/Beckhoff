package de.beckhoff.jni;

public class JNIByteBuffer {
   private byte[] mByteArray;
   private int mUsedBytesCount;

   public JNIByteBuffer() {
      this.mUsedBytesCount = 0;
      this.mByteArray = new byte[0];
   }

   public JNIByteBuffer(byte[] lByteArray) {
      if (lByteArray != null) {
         this.mByteArray = lByteArray;
         this.mUsedBytesCount = this.mByteArray.length;
      } else {
         this.mByteArray = new byte[0];
         this.mUsedBytesCount = 0;
      }

   }

   public JNIByteBuffer(int lUsedBytesCount) {
      this.mUsedBytesCount = lUsedBytesCount;
      this.mByteArray = new byte[lUsedBytesCount];
   }

   /** @deprecated */
   @Deprecated
   public JNIByteBuffer(byte[] lByteArray, int lUsedBytesCount) {
      this(lByteArray, lUsedBytesCount, false);
   }

   public JNIByteBuffer(byte[] lByteArray, int lUsedBytesCount, boolean affectByteCount) throws IllegalArgumentException {
      if (affectByteCount) {
         if (lByteArray == null) {
            throw new IllegalArgumentException("This constructor does not allow for lByteArray to be null");
         }

         if (lUsedBytesCount < 0) {
            throw new IllegalArgumentException("This constructor does not allow for lUsedBytesCount to be negative.");
         }

         this.mByteArray = new byte[lUsedBytesCount];
         this.mUsedBytesCount = lUsedBytesCount;

         for(int i = 0; i < lUsedBytesCount && i < lByteArray.length; ++i) {
            this.mByteArray[i] = lByteArray[i];
         }
      } else {
         this.mByteArray = lByteArray;
         this.mUsedBytesCount = lUsedBytesCount;
      }

   }

   /** @deprecated */
   @Deprecated
   public void setByteArray(byte[] lByteArray) {
      this.setByteArray(lByteArray, false);
   }

   public void setByteArray(byte[] lByteArray, boolean affectByteCount) {
      this.mByteArray = lByteArray;
      if (affectByteCount) {
         if (lByteArray != null) {
            this.mUsedBytesCount = lByteArray.length;
         } else {
            this.mUsedBytesCount = 0;
         }
      }

   }

   public byte[] getByteArray() {
      return this.mByteArray;
   }

   /** @deprecated */
   @Deprecated
   public void setUsedBytesCount(int lUsedBytesCount) {
      this.setUsedBytesCount(lUsedBytesCount, false);
   }

   public void setUsedBytesCount(int lUsedBytesCount, boolean affectByteArray) {
      this.mUsedBytesCount = lUsedBytesCount;
      if (affectByteArray) {
         byte[] newByte = new byte[lUsedBytesCount];

         for(int i = 0; i < lUsedBytesCount && i < this.mByteArray.length; ++i) {
            newByte[i] = this.mByteArray[i];
         }

         this.mByteArray = newByte;
      }

   }

   public int getUsedBytesCount() {
      return this.mUsedBytesCount;
   }
}
