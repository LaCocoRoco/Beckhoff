package de.beckhoff.jni;

public class JNILong {
   private long mLong;

   public JNILong() {
      this.mLong = 0L;
   }

   public JNILong(long lLong) {
      this.mLong = lLong;
   }

   public void setLong(long lLong) {
      this.mLong = lLong;
   }

   public long getLong() {
      return this.mLong;
   }
}
