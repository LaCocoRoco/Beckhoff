package de.beckhoff.jni;

public class JNIBool {
   private boolean mBool;

   public JNIBool() {
      this.mBool = false;
   }

   public JNIBool(boolean lbool) {
      this.mBool = lbool;
   }

   public void setBool(boolean lbool) {
      this.mBool = lbool;
   }

   public boolean getBool() {
      return this.mBool;
   }
}
