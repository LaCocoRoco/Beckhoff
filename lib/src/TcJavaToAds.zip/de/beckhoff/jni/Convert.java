package de.beckhoff.jni;

public class Convert {
   private Convert() {
   }

   public static byte[] ByteToByteArr(byte data) {
      byte[] result = new byte[]{data};
      return result;
   }

   public static byte ByteArrToByte(byte[] data) {
      int expectedSize = 1;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         return data[0];
      }
   }

   public static byte[] ShortToByteArr(short data) {
      byte base = -1;
      byte[] result = new byte[]{(byte)(data & base), (byte)(data >> 8 & base)};
      return result;
   }

   public static short ByteArrToShort(byte[] data) {
      int expectedSize = 2;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         short base = 255;
         short result = (short)(data[1] & base);
         result = (short)(result << 8 | data[0] & base);
         return result;
      }
   }

   public static byte[] IntToByteArr(int data) {
      byte base = -1;
      byte[] result = new byte[]{(byte)(data & base), (byte)(data >> 8 & base), (byte)(data >> 16 & base), (byte)(data >> 24 & base)};
      return result;
   }

   public static int ByteArrToInt(byte[] data) {
      int expectedSize = 4;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         int base = 255;
         int result = data[3] & base;
         result = result << 8 | data[2] & base;
         result = result << 8 | data[1] & base;
         result = result << 8 | data[0] & base;
         return result;
      }
   }

   public static byte[] LongToByteArr(long data) {
      byte base = -1;
      byte[] result = new byte[]{(byte)((int)(data & (long)base)), (byte)((int)(data >> 8 & (long)base)), (byte)((int)(data >> 16 & (long)base)), (byte)((int)(data >> 24 & (long)base)), (byte)((int)(data >> 32 & (long)base)), (byte)((int)(data >> 40 & (long)base)), (byte)((int)(data >> 48 & (long)base)), (byte)((int)(data >> 56 & (long)base))};
      return result;
   }

   public static long ByteArrToLong(byte[] data) {
      int expectedSize = 8;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         long base = 255L;
         long result = (long)data[7] & base;
         result = result << 8 | (long)data[6] & base;
         result = result << 8 | (long)data[5] & base;
         result = result << 8 | (long)data[4] & base;
         result = result << 8 | (long)data[3] & base;
         result = result << 8 | (long)data[2] & base;
         result = result << 8 | (long)data[1] & base;
         result = result << 8 | (long)data[0] & base;
         return result;
      }
   }

   public static byte[] FloatToByteArr(float data) {
      int resultInt = Float.floatToRawIntBits(data);
      return IntToByteArr(resultInt);
   }

   public static float ByteArrToFloat(byte[] data) {
      int expectedSize = 4;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         int resultInt = ByteArrToInt(data);
         return Float.intBitsToFloat(resultInt);
      }
   }

   public static byte[] DoubleToByteArr(double data) {
      long resultLong = Double.doubleToLongBits(data);
      return LongToByteArr(resultLong);
   }

   public static double ByteArrToDouble(byte[] data) {
      int expectedSize = 8;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         long resultLong = ByteArrToLong(data);
         return Double.longBitsToDouble(resultLong);
      }
   }

   public static byte[] BoolToByteArr(boolean data) {
      byte[] result;
      if (data) {
         result = new byte[]{1};
      } else {
         result = new byte[]{0};
      }

      return result;
   }

   public static boolean ByteArrToBool(byte[] data) {
      int expectedSize = 1;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         boolean result = false;
         if (data[0] == 1) {
            result = true;
         }

         return result;
      }
   }

   public static byte[] CharToByteArr(char data) {
      char base = 255;
      byte[] result = new byte[]{(byte)(data & base), (byte)(data >> 1 & base)};
      return result;
   }

   public static char ByteArrToChar(byte[] data) {
      int expectedSize = 2;
      if (data.length != expectedSize) {
         throw new IllegalArgumentException("The lenght of the array is not equal to the expected size " + expectedSize);
      } else {
         char result = (char)data[0];
         char var10000 = (char)(result << 1 & data[1]);
         return (char)data[0];
      }
   }

   /** @deprecated */
   @Deprecated
   public static byte[] StringToByteArr(String data) {
      return StringToByteArr(data, false);
   }

   public static byte[] StringToByteArr(String data, boolean appendNullByte) {
      if (appendNullByte) {
         if (data.getBytes().length > 0) {
            if (data.getBytes()[data.getBytes().length - 1] != 0) {
               data = data + "\u0000";
            }
         } else if (data.getBytes().length == 0) {
            data = data + "\u0000";
         }
      }

      return data.getBytes();
   }

   public static String ByteArrToString(byte[] data) {
      String result = new String();

      for(int i = 0; i < data.length && data[i] != 0; ++i) {
         result = result + (char)data[i];
      }

      return result;
   }
}
